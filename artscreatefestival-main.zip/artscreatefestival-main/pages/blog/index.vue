<template>
<div>
<div class="grid grid-cols-12 !m-0">
      <div class="col-span-12 sm:col-span-12 md:col-span-8 lg:col-span-8">
        <div class="grid grid-cols-12 !m-0">
          <div class="col-span-12 sm:col-span-12 md:col-span-12 lg:col-span-12 px-4">
            <div class="relative mb-24">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-full md:h-full lg:w-full lg:h-full">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute top-4 left-3 h-full w-full border-8 border-purple px-17 bg-cover | flex flex-col 1xl:justify-center"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-28"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <p class="text-lg my-6">The Prince’s Palace of Monaco reopened last week, making a host of recently restored frescoes available to the public for the first time, Artnet News reported on Monday…</p>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
          <div class="col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-6 px-4">
            <div class="relative mb-20">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute h-full w-full border-8 border-pictonblue px-17 bg-cover | flex flex-col 1xl:justify-center top-4 left-3 sm:top-4 sm:left-3 md:top-3 md:left-3 lg:top-4 lg:left-3"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-lg"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
          <div class="col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-6 px-4">
            <div class="relative mb-20">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute h-full w-full border-8 border-pictonblue px-17 bg-cover | flex flex-col 1xl:justify-center top-4 left-3 sm:top-4 sm:left-3 md:top-3 md:left-3 lg:top-4 lg:left-3"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-lg"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
          <div class="col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-6 px-4">
            <div class="relative mb-20">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute h-full w-full border-8 border-pictonblue px-17 bg-cover | flex flex-col 1xl:justify-center top-4 left-3 sm:top-4 sm:left-3 md:top-3 md:left-3 lg:top-4 lg:left-3"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-lg"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
          <div class="col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-6 px-4">
            <div class="relative mb-20">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute h-full w-full border-8 border-pictonblue px-17 bg-cover | flex flex-col 1xl:justify-center top-4 left-3 sm:top-4 sm:left-3 md:top-3 md:left-3 lg:top-4 lg:left-3"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-lg"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
          <div class="col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-6 px-4">
            <div class="relative mb-20">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute h-full w-full border-8 border-pictonblue px-17 bg-cover | flex flex-col 1xl:justify-center top-4 left-3 sm:top-4 sm:left-3 md:top-3 md:left-3 lg:top-4 lg:left-3"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-lg"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
          <div class="col-span-12 sm:col-span-12 md:col-span-6 lg:col-span-6 px-4">
            <div class="relative mb-20">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute h-full w-full border-8 border-pictonblue px-17 bg-cover | flex flex-col 1xl:justify-center top-4 left-3 sm:top-4 sm:left-3 md:top-3 md:left-3 lg:top-4 lg:left-3"></div>
              </div>
              <div class="flex items-center gap-4 mb-6 mt-11 pl-3">
                <img src="../../assets/images/clock-icon.svg">
                <p class="text-pictonblue">07 05 2022</p>
              </div>
              <div class="relative pl-3">
                <h2 class="uppercase text-lg"><a href="#">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a></h2>
                <div class="relative inline-block mt-4"><button class="border-3 | relative z-10 | px-4 py-2 | transition-all duration-100 ease-in bg-purple border-4 border-white text-white text-18 1md:text-base  hover:text-purple hover:border-purple hover:bg-white">
                  Read More
                </button> <div class="absolute w-full h-full top-1.5 right-1.5" style="background:linear-gradient(to right, #fea751, #A95EA4);"></div></div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-center pt-10 hidden sm:hidden md:block lg:block">
          <ul class="flex items-center justify-center gap-5">
            <li class="first-child">
              <a href="#">
                <img src="../../assets/images/left-arrow-side.svg">
              </a>
            </li>
            <li>
              <a href="#" class="w-7 h-7 leading-7 font-bold text-22 font-display flex items-center justify-center hover:bg-purple hover:text-white">1</a>
            </li>
            <li>
              <a href="#" class="w-7 h-7 leading-7 font-bold text-22 font-display flex items-center justify-center hover:bg-purple hover:text-white">2</a>
            </li>
            <li>
              <a href="#" class="w-7 h-7 leading-7 font-bold text-22 font-display flex items-center justify-center hover:bg-purple hover:text-white">3</a>
            </li>
            <li>
              <a href="#">
                <img src="../../assets/images/right-arrow-side.svg">
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-span-12 sm:col-span-12 md:col-span-4 lg:col-span-4 hidden sm:hidden md:block lg:block">
        <div class="pl-0 sm:pl-0 md:pl-5 lg:pl-24">
          <h2 class="uppercase mb-12">Blog</h2>
          <ul class="mb-12">
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
          </ul>
          <h2 class="uppercase mb-12">archive</h2>
          <ul>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–June(20)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–May(52)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–April(21)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–March(8)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–February(14)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–January(3)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2020–(82)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2019–(23)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2018(49)</a></li>
          </ul>
        </div>
    </div>
  </div>
  <div class="follow mt-12 hidden sm:hidden md:block lg:block">
    <div class="flex items-baseline gap-14 mb-10">
      <h2 class="text-28 uppercase">follow us</h2>
      <p class="font-normal block text-purple border-b border-purple"> @createartsfestival</p>
    </div>
    <ul class="flex items-center gap-4">
      <li>
        <img src="../../assets/images/follow-1.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-2.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-3.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-4.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-5.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-6.png" class="w-ful">
      </li>
    </ul>
  </div>
</div>
</template>

<script>
export default {
  name: "index.vue"
}
</script>

<style>
body{@apply relative;}
body::after{
  content: '';
  background: url(../../assets/images/bg-body-dots.svg);
  @apply bg-no-repeat bg-center bg-cover w-full h-full block;
}


</style>
