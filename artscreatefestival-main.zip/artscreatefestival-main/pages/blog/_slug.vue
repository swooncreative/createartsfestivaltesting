<template>
<div>
<div class="grid grid-cols-12 !m-0">
      <div class="col-span-12 sm:col-span-12 md:col-span-8 lg:col-span-8">
        <div class="grid grid-cols-12 !m-0">
          <div class="col-span-12 sm:col-span-12 md:col-span-12 lg:col-span-12 px-4">
            <div class="relative mb-24">
              <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-full md:h-full lg:w-full lg:h-full">
                <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                <div class="absolute top-4 left-3 h-full w-full border-8 border-purple px-17 bg-cover | flex flex-col 1xl:justify-center"></div>
              </div>
              <div class="block sm:block md:block lg:flex items-center justify-between mb-6 mt-11 pl-3">
                <div class="flex items-center gap-4">
                  <img src="../../assets/images/clock-icon.svg">
                    <p class="text-pictonblue">07 05 2022</p>
                </div>
                <p class="uppercase">BY SHANTI ESCALANTE-DE MATTEI</p>
              </div>
              

              <div class="relative pl-3">
                <h2 class="uppercase text-28 mb-6">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</h2>
                <p class="text-lg mb-5">The Prince’s Palace of Monaco reopened last week, making a host of recently restored frescoes available to the public for the first time, Artnet News reported on Monday…</p>
                <p class="text-lg mb-5">The Renaissance-era frescoes were discovered hidden behind layers of paint in 2015 during restorations to the palace that began in 2013. The Palace’s reopening comes after years of repairs, closures, and delays due in part to the COVID-19 pandemic.</p>
                <p class="text-lg mb-5">“This discovery places the Grimaldi family and Palace of Monaco within a new art historical context as a Renaissance palace,” Julia Greiner, the Palace’s chief conservator-restorer told Artnet News.</p>
                <p class="text-lg mb-5">“The discovery has ignited numerous research projects including conservation and sustainability which have been inspired through his sovereign highness, Prince Albert II’s interest and dedication to environmental issues. Furthermore it has brought together a pluridisciplinary team of approximately 40 specialists that have worked on this project for the last 8 years.”</p>
                <p class="text-lg mb-5">Built in 1197, the Palace of Monaco has been inhabited by the Grimaldi family ever since they overtook the fortress in 1297. Unlike royal families like the Hapsburgs or Romanovs, the Grimaldis did not have the consistent fortune or vast lands necessary to regularly build new palaces; after all, Monaco is the second-smallest independent state in the world.</p>
                <p class="text-lg mb-5">The Grimaldis stuck to the same palace for centuries, expanding or updating to keep with the fashions of the times, possibly explaining why the frescoes were covered up.</p>
                <p class="text-lg mb-5">Today, the Palace is occupied by Albert II, who began his rule in 2005. The Palace and its frescoes are on view to the public until October 15th.</p>
                <div class="my-20">
                <div class="grid grid-cols-12 !m-0 gap-4">
                  <div class="col-span-12 sm:col-span-12 md:col-span-12 lg:col-span-6">
                    <p class="text-lg mb-5">The Prince’s Palace of Monaco reopened last week, making a host of recently restored frescoes available to the public for the first time, Artnet News reported on Monday</p>
                    <p class="text-lg mb-5">The Renaissance-era frescoes were discovered hidden behind layers of paint in 2015 during restorations to the palace that began in 2013. The Palace’s reopening comes after years of repairs, closures, and delays due in part to the COVID-19 pandemic.</p>
                    <p class="text-lg mb-5">“This discovery places the Grimaldi family and Palace of Monaco within a new art historical context as a Renaissance palace,” Julia Greiner, the Palace’s chief conservator-restorer told Artnet News.</p>
                  </div>
                  <div class="col-span-12 sm:col-span-12 md:col-span-12 lg:col-span-6">
                    <div class="relative w-full h-342 sm:w-full sm:h-342 md:w-56 md:h-56 lg:w-96 lg:h-96">
                      <img src="../../assets/images/blog-img.png" class="w-full h-full object-cover">
                      <div class="absolute h-full w-full border-8 border-purple px-17 bg-cover | flex flex-col 1xl:justify-center top-4 right-3 sm:top-4 sm:right-3 md:top-3 md:right-3 lg:top-4 lg:right-3"></div>
                    </div>
                  </div>
                </div>
                </div>
                <p class="text-lg mb-5">The Prince’s Palace of Monaco reopened last week, making a host of recently restored frescoes available to the public for the first time, Artnet News reported on Monday.</p>
                <p class="text-lg mb-5">The Renaissance-era frescoes were discovered hidden behind layers of paint in 2015 during restorations to the palace that began in 2013. The Palace’s reopening comes after years of repairs, closures, and delays due in part to the COVID-19 pandemic.</p>
                <p class="text-lg mb-5">“This discovery places the Grimaldi family and Palace of Monaco within a new art historical context as a Renaissance palace,” Julia Greiner, the Palace’s chief conservator-restorer told Artnet News.</p>
                <p class="text-lg mb-5">“The discovery has ignited numerous research projects including conservation and sustainability which have been inspired through his sovereign highness, Prince Albert II’s interest and dedication to environmental issues. Furthermore it has brought together a pluridisciplinary team of approximately 40 specialists that have worked on this project for the last 8 years.”</p>
                <p class="text-lg mb-5">Built in 1197, the Palace of Monaco has been inhabited by the Grimaldi family ever since they overtook the fortress in 1297. Unlike royal families like the Hapsburgs or Romanovs, the Grimaldis did not have the consistent fortune or vast lands necessary to regularly build new palaces; after all, Monaco is the second-smallest independent state in the world.</p>
                <p class="text-lg mb-5">The Grimaldis stuck to the same palace for centuries, expanding or updating to keep with the fashions of the times, possibly explaining why the frescoes were covered up.</p>
                <p class="text-lg mb-5">Today, the Palace is occupied by Albert II, who began his rule in 2005. The Palace and its frescoes are on view to the public until October 15th.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-span-12 sm:col-span-12 md:col-span-4 lg:col-span-4 hidden sm:hidden md:block lg:block">
        <div class="pl-0 sm:pl-0 md:pl-5 lg:pl-24">
          <h2 class="uppercase mb-12">Blog</h2>
          <ul class="mb-12">
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
            <li class="border-b-2 border-purple mb-7">
              <a href="#" class="underline font-medium text-18">See The 500-Year-Old Frescoes Discovered During Restoration of the Prince’s Palace of Monaco</a>
              <div data-v-d75a0a44="" class="flex items-center gap-4 mb-5 mt-12"><img data-v-d75a0a44="" src="/_nuxt/assets/images/clock-icon.svg"> <p data-v-d75a0a44="" class="text-pictonblue">07 05 2022</p></div>
            </li>
          </ul>
          <h2 class="uppercase mb-12">archive</h2>
          <ul>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–June(20)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–May(52)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–April(21)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–March(8)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–February(14)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2022–January(3)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2020–(82)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2019–(23)</a></li>
            <li class="mb-6"><a href="#" class="font-medium text-18 border-b border-black">2018(49)</a></li>
          </ul>
        </div>
    </div>
  </div>
  <div class="follow mt-12 hidden sm:hidden md:block lg:block">
    <div class="flex items-baseline gap-14 mb-10">
      <h2 class="text-28 uppercase">follow us</h2>
      <p class="font-normal block text-purple border-b border-purple"> @createartsfestival</p>
    </div>
    <ul class="flex items-center gap-4">
      <li>
        <img src="../../assets/images/follow-1.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-2.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-3.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-4.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-5.png" class="w-ful">
      </li>
      <li>
        <img src="../../assets/images/follow-6.png" class="w-ful">
      </li>
    </ul>
  </div>
</div>
</template>

<script>
export default {
  name: "blog-details.vue"
}
</script>

<style>
body{@apply relative;}
body::after{
  content: '';
  background: url(../../assets/images/bg-body-dots.svg);
  @apply bg-no-repeat bg-center bg-cover w-full h-full block;
}


</style>
